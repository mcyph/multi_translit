% korean parser: Soyoung Kwon
% This is a dependency parser for Korean that uses GULP
% last modified: May 10 2003


:- ensure_loaded('c://Program Files//pl//bin//GULP3swi.pl').

%%lexicon word(phonetic sound, partofspeech(features)).
%%There is a distinction between casemarker(pp) and verbal-endings(p).

word(ga,pp(case:nom..ending:vow)).
word(i,pp(case:nom..ending:con)).    
word(lul,pp(case:acc..ending:vow)).
word(ul,pp(case:acc..ending:con)).
word(nun-da,p(tense:pres..ending:con)).
word(n-da,p(tense:pres..ending:vow)).
word(gang-a-gi,n(ending:vow..sem:dog)).
word(go-yang-i,n(ending:vow..sem:cat)).
word(chot,v(ending:con..subcat:2..sem:chase)).
word(yeppun,adj(sem:pretty)).

%% dependency rule : the order in a sentence needs to be considered.
%% each word is represented as,
%% [NumberInSentence,DependentList,PhoneticSound,PartofSpeech,GULPfeatures]

% noun/postpositional case marker
check_dh([NN,_,_,n,X],[N,_,_,pp,Y]) :- !, X = ending:End,Y = ending:End, N is NN +1.

% verb/inflections(the head of a sentence)
check_dh([NN,_,_,v,X],[N,_,_,p,Y]) :- !, X = ending:End,Y = ending:End, N is NN +1.

% subject/case marker, object/case marker
check_dh([NN,_,_,pp,_],[N,_,_,v,_]) :- !, N > NN.

% adjective/noun
check_dh([NN,_,_,adj,_],[N,_,_,n,_]) :- !, N is NN+1.



%%modified parsing algorithm of Dr. Covington.


% parse(+InputList,-Result)
%  Parses a list of words, giving a HeadList.

parse(InputList,Result) :-
   parse_loop(1,InputList,[],[],Result).


% parse_loop(+Count,+InputList,+WordList,+HeadList,-Result)
%  Called by parse/2, to loop through the list.

parse_loop(Count,[Word|InputList],WordList,HeadList,Result) :-
   word(Word,WordFeatures),
   WordFeatures =.. X,  %need to change the features to a list.
   Node= [Count,_,Word|X], % the node will be a list of
                           %[numberinsentence,dependentlist,phoneticsound,the GULP features].
   parse_node(Node,WordList,HeadList,NewHeadList), % Try to attach it
   NewCount is Count + 1,
   NewWordList = [Node|WordList],                    % Add Node to WordList
   parse_loop(NewCount,InputList,NewWordList,NewHeadList,Result).


% No more words to parse; so Result := HeadList.
% The pp,p,and v cannot come alone in a sentence.
parse_loop(_,[],_,[H],[H]):- \+ (H = [_,[],_,pp,_];
				 H = [_,[],_,p,_];
				 H = [_,[],_,v,_]   
				
				).

  



% parse_node(+Node,+WordList,+HeadList,-NewHeadList)
%  Try to attach Node to the dependency tree.
%  HeadList gets modified here; WordList does not
%  (except by instantiation).

parse_node(Node,[],[],[Node]) :- !.
   % If this is the first word, just add it to HeadList.

parse_node(Node,WordList,HeadList,NewHeadList) :-
   try_inserting_as_head(Node,HeadList,HeadList2),
   try_inserting_as_dependent(Node,WordList,HeadList2,NewHeadList).




% try_inserting_as_head(+Node,+HeadList,-NewHeadList)
%  Try to insert Node as the head above a word presently in HeadList.
%  This entails deleting an element from HeadList.

try_inserting_as_head(_,[],[]).
   % No more elements of HeadList to look at.

try_inserting_as_head(Node,[Head|HeadList],NewHeadList) :-
   % Insert Node above Head, and remove Head from HeadList.
   Node = [N,D,_|X],
   Head = [NN,_,_|Y],
   check_dh(Head,Node),  % Head is the dependent here
   add_item(D,Head),
   % Now recurse down HeadList and see if it can be done again.
   % (Multiple elements of HeadList may be dependents of Node.)
   try_inserting_as_head(Node,HeadList,NewHeadList).


try_inserting_as_head(Node,[Head|HeadList],[Head|NewHeadList]) :-
   % Couldn't use Head, so skip it.
   try_inserting_as_head(Node,HeadList,NewHeadList).


% try_inserting_as_dependent(+Node,+WordList,+HeadList,-NewHeadList)
%  Try to insert Node as a dependent of a word already encountered,
%  i.e., of an element of WordList.
%  Alternatively, add Node to HeadList.


try_inserting_as_dependent(Node,WordList,HeadList,HeadList) :-
   member(Word,WordList),
   Word = [NN,D,_|X],
   Node = [N,_,_|Y], 
   check_dh(Node,Word),
   add_item(D,Node).


try_inserting_as_dependent(Node,_,HeadList,[Node|HeadList]).
   % couldn't attach it, so add it to HeadList



%
% LIST UTILITIES
%


% add_item(?OpenList,+Item)
%   adds Item just before the tail of OpenList

add_item(X,Item) :- var(X), !, X = [Item|_].

add_item([_|X],Item) :- add_item(X,Item).


% Output utilities


write_list([First|Rest]) :-
   var(First),
   !,
   write('_ '),
   write_list(Rest).

write_list([First|Rest]) :-
   write(First),
   write(' '),
   write_list(Rest).

write_list([]) :-
   nl.


write_dep(Node) :-
   write_dep(Node,0).

write_dep([N,Dependents|Rest],Indentation) :-
   tab(Indentation),
   write(N),
   write(' '), 
   NewIndentation is Indentation + 3,tab(Indentation),
   display_feature_structure(Rest),   %% displays the GULP features
   write_dep_open_list(Dependents,NewIndentation).

write_dep_open_list(X,_) :-
   var(X),
   !.

write_dep_open_list([First|Rest],N) :-
   write_dep(First,N),
   write_dep_open_list(Rest,N).



% tests

try(List) :- write_list(List),nl,
             parse(List,[Head]),
             write_dep(Head),
	     nl,
	     fail.

try(_) :- write('No (more) parses.'), nl.



/*test1 :- try([gang-a-gi,ga,go-yang-i,lul,chot,nun-da]). %should succeed
test2 :- try([go-yang-i,lul,gang-a-gi,ga,chot,nun-da]).  %should succeed
test3 :- try([yeppun,gang-a-gi,ga,go-yang-i,lul,chot,nun-da]). %should succeed
test4 :- try([go-yang-i,lul,chot,gang-a-gi,ga,un-da]).  %should fail
test5 :- try([gang-a-gi,yeppun,ga,go-yang-i,lul,chot,nun-da]). %should fail*/






