%% Working Grammar for Korean parser with GULP
%% By: Soyoung Kwon
%% Last Modified: May 11 2003



%% Be sure to load the parser and the GULPswi.pl.

:- ensure_loaded('koreanparsergulp.pl').
:- ensure_loaded('c://Program Files//pl//bin//GULP3swi.pl').

%%lexicon: vocabulary

word(ga,pp(case:nom..ending:vow)).
word(i,pp(case:nom..ending:con)).    
word(lul,pp(case:acc..ending:vow)).
word(ul,pp(case:acc..ending:con)).
word(nun-da,p(tense:pres..ending:con)).
word(n-da,p(tense:pres..ending:vow)).
word(gang-a-gi,n(ending:vow..sem:dog)).
word(go-yang-i,n(ending:vow..sem:cat)).
word(sa-ram-dul,n(ending:con..sem:people)).
word(han-guk,n(ending:con..sem:korea)).
word(chot,v(ending:con..subcat:2..sem:chase)).
word(sa-rang-ha,v(ending:vow..suncat:2..sem:love)).
word(yeppun,adj(sem:pretty)).
word(modun,adj(sem:all)).

%%dependency rules

% noun/postpositional case marker
check_dh([NN,_,_,n,X],[N,_,_,pp,Y]) :- !, X = ending:End,Y = ending:End, N is NN +1. 

% verb/inflections(the head of a sentence)
check_dh([NN,_,_,v,X],[N,_,_,p,Y]) :- !, X = ending:End,Y = ending:End, N is NN +1.

% subject/case marker, object/case marker
check_dh([NN,_,_,pp,_],[N,_,_,v,_]) :- !, N > NN.  % 'preceding restriction'

% adjective/noun
check_dh([NN,_,_,adj,_],[N,_,_,n,_]) :- !, N is NN+1. % 'adjacency restriction'



%%%
%%%tests (succeeding cases)
%%%

% test1 & test2 succeed : pp follows nouns/ p follows v/ case marker, pp, 
%                 comes before v (nom,acc marker can come anywhere before v)

test1 :- try([gang-a-gi,ga,go-yang-i,lul,chot,nun-da]). %'dog,pp(nom),cat,pp(acc),chase,p'
test2 :- try([go-yang-i,lul,gang-a-gi,ga,chot,nun-da]).  %'cat,pp(acc),dog,pp(nom),chase,p'

% test1 & test3 succeed : ending feature agreement

test1 :- try([gang-a-gi,ga,go-yang-i,lul,chot,nun-da]). % 'gang-a-gi' & 'ga' : vow
                                                        % 'go-yang-i' & 'lul' : vow
                                                        % 'chot' & 'nun-da' : con
test3 :- try([sa-ram-dul,i,han-guk,ul,sa-rang-ha,n-da]). % 'sa-ram-dul','i' : con
                                                         % 'han-guk','ul' : con
                                                         % 'sa-rang-ha','n-da' : vow

% test4 succeeds : adj. comes right before the nouns (adjacency rule)

test4 :- try([yeppun,gang-a-gi,ga,go-yang-i,lul,chot,nun-da]). % 'pretty,dog,pp(nom),cat,pp(acc),chase,p'

% test5 succeeds : the verb that has a "subcategorization:2" feature,
%                  can have only one noun or two nouns at the most.

test5 :-  try([sa-ram-dul,i,sa-rang-ha,n-da]). % v being a HEAD of one pp,'i'.
test6 :-  try([han-guk,ul,sa-rang-ha,n-da]) %  v being a HEAD of one pp,'ul'.

%%%   
%%%tests( failng cases)
%%%
   
% test5 & test6 fail : pp does not follow right after nouns/ case marker comes after v/
%                       p does not follow right after v

test7 :- try([ga,gang-a-gi,go-yang-i,lul,nun-da,chot]). %'pp(nom),dog,cat,pp(acc),p,chase'
test8 :- try([gang-a-gi,ga,chot,nun-da,lul,goyang-i]). %'dog,pp(nom),chase,p,pp(acc),cat'

% test7 fails : does not agree on the ending feature agreement
 
test9 :- try([sa-ram-dul,ga,han-guk,lul,chot,un-da]). % all the ending features are not matched.

% test8 fails : adj. does not come right before the nouns 

test10 :- try([gang-a-gi,ga,go-yang-i,lul,yeppun,chot,nun-da]). %'dog,pp(nom),cat,pp(acc),pretty,chase,p'

% test11 & test12 & test13  fails : pp/p/v cannot stand alone in a sentence.

test11 :- try([ga]).
test12 :- try([un-da]).
test13 :- try([sa-rang-ha]).




